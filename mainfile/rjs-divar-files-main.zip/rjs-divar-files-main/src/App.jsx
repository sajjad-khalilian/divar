function App() {
  return <h1>پروژه دیوار</h1>;
}

export default App;
